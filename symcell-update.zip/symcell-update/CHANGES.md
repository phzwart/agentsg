# symcell update — 0.4.1 → 0.4.2

Drop-in update for a repo you've modified elsewhere. Only the files below changed
this session; merge them selectively rather than overwriting your tree.

## Files to merge

| file | change |
|------|--------|
| `src/symcell/cell/rootform.py` | **new functions** (additive; nothing removed) |
| `src/symcell/cell/__init__.py` | added the new names to imports + `__all__` |
| `tests/test_volume_decomposition.py` | new test file (47 tests) |
| `README.md` | new "volume decomposition" + "cutoff selection" sections |
| `pyproject.toml` | version bump 0.4.1 → 0.4.2 |

If your `__init__.py` / `README.md` / `pyproject.toml` have diverged, hand-merge
those three; `rootform.py` additions are self-contained functions you can paste in.

## What's new in `rootform.py` (all additive, zero-dependency)

Volume / shape decomposition:
- `root_volume_decomposition(cell_A, cell_B)` → `{total, volume_component,
  shape_residual, scale_factor, volume_ratio, coupling_angle_deg}`
- `similarity_invariant(cell)` = `RI(cell) / V**(1/3)` (shape-only key)
- `similarity_distance(cell_A, cell_B)` (0 iff similar/isotropic copies)

Edge-tolerance → cutoff:
- `root_cutoff_for_edge_tolerance(max_edge_change, cell=None, n_edges=1)`

Volume-ratio ↔ distance, and symmetry cutoff (this session):
- `root_distance_to_volume_ratio(distance, cell)` → `V'/V = (1 + d/‖RI‖)**3`
- `volume_ratio_to_root_distance(volume_ratio, cell)` (inverse)
- `symmetry_cutoff(cell, volume_tol=…)` or `symmetry_cutoff(cell, noise_frac=…, z=11)`
  — scale-correct cutoff for accepting a Reynolds-symmetrised cell; both forms
  return `(dimensionless) · ‖RI(cell)‖`, so they track cell scale and per-system
  spread automatically.

## Analysis outputs (reference figures + calibration data, not code)

`analysis/` holds the figures and `.npz` calibration arrays behind these results
(volume decomposition, edge-cutoff, hypersphere coverage, symmetry cutoff). Drop
them wherever you keep analysis artifacts, or ignore them — they're not imported.

## Verify after merge

```bash
pip install -e ".[db]"
pytest tests/test_volume_decomposition.py -q     # 47 passed
pytest -q                                         # full suite
```
